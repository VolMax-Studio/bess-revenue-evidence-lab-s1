# Evidence Lab #002: Public Evidence Package

This package contains the public verifiable evidence artifacts for the August 2026 European BESS revenue benchmarks published via bess-index.com.

## Scope of Included Evidence
Contains strictly the minimal evidence extract required to evaluate and verify these claims:
- Extracted August 2026 benchmark rows for Germany (DE), Belgium (BE), and Spain (ES).
- Declared provider methodology parameters (degradation, foresight, cycling, revenue streams, basis).
- Formal claim JSON definitions (`claims/`).
- Hash-bound execution receipts (`evidence/`).
- Deterministic verification engine (`verifier/verify.py`).
- Automated test suite (`tests/test_verifier.py`).
- Cryptographic SHA-256 integrity manifest (`data/MANIFEST.sha256`).

## Audit Custody Disclosure
Full raw web source snapshots are retained in private audit custody pending redistribution clearance. Public source URLs, extracted evidence used by the verifier, deterministic verification code, and cryptographic hashes are available for inspection.

## How to Verify Locally
Independently reproduce the Evidence Lab calculations from the packaged extracted dataset:
```bash
./reproduce.sh
```
