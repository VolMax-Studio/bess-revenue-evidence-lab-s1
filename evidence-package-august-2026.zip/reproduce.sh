#!/usr/bin/env bash
set -euo pipefail

echo "================================================================="
echo "  EVIDENCE LAB: European BESS Revenue Benchmarks"
echo "  Public Deterministic Evidence Verification"
echo "================================================================="

echo "[1/3] Verifying integrity of extracted datasets..."
cd data
sha256sum -c MANIFEST.sha256
cd ..
echo "-> Integrity PASS."

echo ""
echo "[2/3] Running Tier 1 & Tier 2 Verifiers..."
python3 verifier/verify.py claims/claim_de_spread.json
python3 verifier/verify.py claims/claim_be_spread.json
python3 verifier/verify.py claims/claim_es_spread.json

set +e
python3 verifier/verify.py claims/claim_de_negative_ctrl.json > /dev/null
NEG_CODE=$?
set -e
if [ "$NEG_CODE" -eq 1 ]; then
  echo "VERIFIED: Negative control rejected (exit code 1)."
else
  echo "FAIL: Negative control check failed."
  exit 1
fi

python3 verifier/verify.py claims/claim_de_comparability.json
echo "-> Verifier PASS."

echo ""
echo "[3/3] Executing verification test suite..."
python3 -m unittest discover -s tests -v

echo ""
echo "================================================================="
echo "  VERIFICATION COMPLETE: 100% PASS"
echo "================================================================="
